
#call the necesary notebooks and packages...
using NBInclude
using LightGraphs
nbinclude("C:\\Users\\Daniel\\MasterThesis\\admmRecovery.ipynb")

#Read matrices...
#nips21 = readdlm("nips21.txt")
#nips22 = readdlm("nips22.txt")
#nips23 = readdlm("nips23.txt")
#nips24 = readdlm("nips24.txt")
#nips25 = readdlm("nips25.txt")
#nips26 = readdlm("nips26.txt")

#store them in an array and add ones on the diagonal.
Nips = Array{Any}(6)
Nips[1]= readdlm("nips21.txt")+diagm(ones(5722))
Nips[2]= readdlm("nips22.txt")+diagm(ones(5722))
Nips[3]= readdlm("nips23.txt")+diagm(ones(5722))
Nips[4]= readdlm("nips24.txt")+diagm(ones(5722))
Nips[5]= readdlm("nips25.txt")+diagm(ones(5722))
Nips[6]= readdlm("nips26.txt")+diagm(ones(5722))
1

#recover the clusters...
tic()
recover=admmRecovery(Nips,3,5722,1.6,1.0e-4,200)
toc()

#real matrix
RealRecovery=(recover[1]+ones(5722)*ones(5722)')/2
#save results
writedlm("NipsRecovered.txt",RealRecovery)

#Conected components
tic()
g = Graph(RealRecovery)
comps =connected_components(g)
toc()

RealRecovery


